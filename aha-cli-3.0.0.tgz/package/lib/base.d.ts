import AhaAPI from './api';
import { FlagDefinition } from './lib/flags';
import { ParsedArgs } from './lib/parse';
interface ApiAuth {
    token: string;
    url: string;
}
declare abstract class BaseCommand {
    static description: string;
    static needsAuth: boolean;
    static flags: Record<string, FlagDefinition>;
    argv: string[];
    flags: Record<string, string | boolean>;
    _auth?: ApiAuth;
    _api?: AhaAPI;
    constructor(argv: string[]);
    execute(): Promise<void>;
    init(): Promise<void>;
    parse(cmdClass?: typeof BaseCommand): ParsedArgs;
    abstract run(): Promise<void>;
    get api(): AhaAPI;
    initAPI(): Promise<AhaAPI>;
    resetAPI(): void;
    loadAuth(): Promise<ApiAuth>;
    log(message?: string, ...args: unknown[]): void;
    error(input: string | Error, options?: {
        exit?: number | false;
    }): void;
    catch(error: unknown): Promise<void>;
}
export default BaseCommand;
