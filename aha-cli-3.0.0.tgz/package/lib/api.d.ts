interface IConfig {
    baseURL: string;
}
interface RequestOptions {
    body?: unknown;
    headers?: Record<string, string>;
}
declare class AhaAPI {
    config: IConfig;
    defaults: {
        headers: Record<string, string>;
    };
    constructor(config: IConfig);
    get(url: string, options?: RequestOptions): Promise<{
        body: unknown;
        response: Response;
    }>;
    put(url: string, options?: RequestOptions): Promise<{
        body: unknown;
        response: Response;
    }>;
    post(url: string, options?: RequestOptions): Promise<{
        body: unknown;
        response: Response;
    }>;
    delete(url: string, options?: RequestOptions): Promise<{
        body: unknown;
        response: Response;
    }>;
    private request;
}
export default AhaAPI;
