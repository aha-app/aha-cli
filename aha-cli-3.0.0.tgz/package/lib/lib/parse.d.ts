import { FlagDefinition } from './flags';
export type FlagValue = string | boolean;
export interface ParsedArgs {
    flags: Record<string, FlagValue>;
    args: Record<string, string>;
    argv: string[];
}
export declare function parseArgs(argv: string[], flagDefs: Record<string, FlagDefinition>): ParsedArgs;
