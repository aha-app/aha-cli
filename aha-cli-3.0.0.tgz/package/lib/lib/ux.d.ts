declare class TreeNode {
    nodes: Record<string, TreeNode>;
    insert(label: string): void;
    display(prefix?: string, isRoot?: boolean): void;
}
export declare const ux: {
    action: {
        start(msg: string): void;
        stop(msg?: string): void;
    };
    warn(input: unknown): void;
    tree(): TreeNode;
};
export {};
