export interface StringFlagConfig {
    type: 'string';
    char?: string;
    description?: string;
    default?: string;
    required?: boolean;
}
export interface BooleanFlagConfig {
    type: 'boolean';
    char?: string;
    description?: string;
    default?: boolean;
}
export type FlagDefinition = StringFlagConfig | BooleanFlagConfig;
export declare const Flags: {
    string(config?: Omit<StringFlagConfig, "type">): StringFlagConfig;
    boolean(config?: Omit<BooleanFlagConfig, "type">): BooleanFlagConfig;
};
