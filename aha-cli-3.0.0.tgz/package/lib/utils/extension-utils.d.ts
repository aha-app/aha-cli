import BaseCommand from '../base';
import { PackageConfiguration } from './extension-types';
export declare function readConfiguration(): PackageConfiguration;
export declare function identifierFromConfiguration(configuration: PackageConfiguration): string;
export declare function fetchRemoteTypes(extensionRoot?: string): Promise<void>;
export declare function installExtension(command: BaseCommand, dumpCode: boolean, skipCache?: boolean): Promise<void>;
export declare function buildExtension(command: BaseCommand, skipCache?: boolean): Promise<void>;
