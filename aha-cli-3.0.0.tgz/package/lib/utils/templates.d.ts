import fs from 'fs';
import { AhaExtensionConfig, ContributionConfig } from './extension-types';
type TemplateFileSystem = Pick<typeof fs, 'existsSync' | 'mkdirSync' | 'writeFileSync'>;
type ContributionMap = Record<string, Record<string, ContributionConfig>>;
declare const templates: {
    writeContributionTemplates(fs: TemplateFileSystem, directory: string, name: string, contributions: ContributionMap): void;
    viewsTemplate(contributionName: string, contribution: ContributionConfig, _identifier: string): string;
    commandsTemplate(contributionName: string, _contribution: ContributionConfig, _identifier: string): string;
    endpointsTemplate(contributionName: string): string;
    importersTemplate(contributionName: string, contribution: ContributionConfig, identifier: string): string;
    eventsTemplate(contributionName: string, contribution: ContributionConfig, _identifier: string): string;
    packageTemplate(identifier: string, name: string, author: string, ahaExtensionsSchema: AhaExtensionConfig): string;
    readmeTemplate(name: string): string;
    tsconfigTemplate(): string;
    vscodeTemplate(): string;
    gitignoreTemplate(): string;
};
export default templates;
