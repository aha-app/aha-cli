import { Plugin } from 'esbuild';
import { SimpleCache } from './simple-cache';
interface HttpPluginOptions {
    cache?: SimpleCache;
}
declare const httpPlugin: (options: HttpPluginOptions) => Plugin;
export { httpPlugin };
