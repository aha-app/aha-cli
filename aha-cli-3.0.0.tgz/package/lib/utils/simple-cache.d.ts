/**
 * A simple filesystem cache that stores keys by hash.
 *
 * ```
 * const cache = await SimpleCache.create('path/to/cache/dir');
 * await cache.has('abc123'); // false
 * await cache.set('abc123', Buffer.from('hello'));
 * await cache.has('abc123'); // true
 * await cache.get('abc123'); // Buffer('hello')
 * ```
 */
export declare class SimpleCache {
    private location;
    /**
     * Create the cache. If the location directory does not exist it will be created
     *
     * @param location Filesystem path
     */
    static create(location: string): Promise<SimpleCache>;
    constructor(location: string);
    /**
     * @param url key identifiying the file
     * @param data file data
     */
    set(url: string, data: Buffer): Promise<void>;
    /**
     * @param url key identifying the file
     * @returns Buffer of the stored file data
     */
    get(url: string): Promise<Buffer>;
    /**
     * @param url key identifying the file
     * @returns true of false if the cache has an entry for the key
     */
    has(url: string): Promise<boolean>;
    /**
     * @param url key identifying the file
     * @returns hashed key
     */
    hash(url: string): string;
}
