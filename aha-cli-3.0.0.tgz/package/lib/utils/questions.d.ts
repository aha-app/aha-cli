type StringAnswers = Record<string, string>;
export declare function getContributionFromQuestions(): Promise<{
    type: string;
    name: string;
    contribution: {
        title: string | undefined;
        entryPoint: string | undefined;
        host: string | undefined;
        location: unknown;
        recordTypes: unknown;
        handles: string[] | undefined;
        description: string | undefined;
        default: string | null | undefined;
        type: string | undefined;
        scope: unknown;
    };
}>;
export declare const extensionQuestions: ({
    type: string;
    name: string;
    message: string;
    default: string;
    validate?: undefined;
} | {
    type: string;
    name: string;
    message: string;
    default?: undefined;
    validate?: undefined;
} | {
    type: string;
    name: string;
    message: string;
    validate: (input: string, _answers: StringAnswers) => true | "The identifier should contain exactly one period" | "The identifier should be a valid NPM package name";
    default?: undefined;
})[];
export declare const addContributionsQuestion: {
    type: string;
    name: string;
    message: string;
    default: boolean;
    choices: {
        name: string;
        value: boolean;
    }[];
}[];
export declare const addAnotherContributionQuestion: {
    type: string;
    name: string;
    message: string;
    default: string;
    choices: string[];
}[];
export declare const contributionQuestions: ({
    type: string;
    name: string;
    message: string;
    default: string;
    choices?: undefined;
    when?: undefined;
    filter?: undefined;
} | {
    type: string;
    name: string;
    message: string;
    default: (answers: StringAnswers) => string;
    choices?: undefined;
    when?: undefined;
    filter?: undefined;
} | {
    type: string;
    name: string;
    message: string;
    choices: {
        name: string;
        value: string;
    }[];
    default: string;
    when?: undefined;
    filter?: undefined;
} | {
    type: string;
    name: string;
    message: string;
    default: (answers: StringAnswers) => string;
    when: (answers: StringAnswers) => boolean;
    choices?: undefined;
    filter?: undefined;
} | {
    type: string;
    name: string;
    message: string;
    choices: {
        name: string;
        value: string;
    }[];
    default: string;
    when: (answers: StringAnswers) => boolean;
    filter?: undefined;
} | {
    type: string;
    name: string;
    message: string;
    choices: {
        name: string;
        value: string;
    }[];
    default: string[];
    when: (answers: StringAnswers) => boolean;
    filter?: undefined;
} | {
    type: string;
    name: string;
    message: string;
    choices: {
        name: string;
        value: {
            menu: string;
        };
    }[];
    default: {
        menu: string;
    };
    when: (answers: StringAnswers) => boolean;
    filter?: undefined;
} | {
    type: string;
    name: string;
    message: string;
    choices: string[];
    default: string;
    when: (answers: StringAnswers) => boolean;
    filter?: undefined;
} | {
    type: string;
    name: string;
    message: string;
    default: (answers: StringAnswers) => "Enable Option" | "Choose a color" | "Description" | "Choose a number" | "Authentication token" | undefined;
    when: (answers: StringAnswers) => boolean;
    choices?: undefined;
    filter?: undefined;
} | {
    type: string;
    name: string;
    message: string;
    default: (answers: StringAnswers) => "true" | "#000000" | "Default String" | "42" | undefined;
    when: (answers: StringAnswers) => boolean;
    choices?: undefined;
    filter?: undefined;
} | {
    type: string;
    name: string;
    message: string;
    default: string;
    filter: (input: string, _answers: StringAnswers) => string[];
    when: (answers: StringAnswers) => boolean;
    choices?: undefined;
})[];
export {};
