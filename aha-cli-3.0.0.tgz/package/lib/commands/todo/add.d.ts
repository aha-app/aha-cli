import BaseCommand from '../../base';
export default class TodoAdd extends BaseCommand {
    static needsAuth: boolean;
    static description: string;
    static flags: {
        due: import("../../lib/flags").StringFlagConfig;
    };
    run(): Promise<void>;
}
