import BaseCommand from '../../base';
export default class Watch extends BaseCommand {
    static needsAuth: boolean;
    static description: string;
    static flags: {
        noCache: import("../../lib/flags").BooleanFlagConfig;
    };
    changedPaths?: string[] | null;
    timeoutHandle?: NodeJS.Timeout | null;
    performingInstall: boolean;
    run(): Promise<void>;
    performInstall(): Promise<void>;
}
