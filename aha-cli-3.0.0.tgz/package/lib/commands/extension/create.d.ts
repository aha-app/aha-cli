import BaseCommand from '../../base';
export default class Create extends BaseCommand {
    static description: string;
    static flags: {
        [x: string]: import("../../lib/flags").FlagDefinition;
    };
    run(): Promise<void>;
}
