import BaseCommand from '../../base';
export default class Install extends BaseCommand {
    static needsAuth: boolean;
    static description: string;
    static flags: {
        dumpCode: import("../../lib/flags").BooleanFlagConfig;
        noCache: import("../../lib/flags").BooleanFlagConfig;
    };
    run(): Promise<void>;
}
