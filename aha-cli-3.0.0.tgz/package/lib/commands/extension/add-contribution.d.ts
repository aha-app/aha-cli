import BaseCommand from '../../base';
export default class AddContribution extends BaseCommand {
    static description: string;
    static flags: {
        [x: string]: import("../../lib/flags").FlagDefinition;
    };
    run(): Promise<void>;
}
