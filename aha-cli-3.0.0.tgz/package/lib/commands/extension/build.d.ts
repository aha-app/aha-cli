import BaseCommand from '../../base';
export default class Build extends BaseCommand {
    static description: string;
    static flags: {
        noCache: import("../../lib/flags").BooleanFlagConfig;
    };
    run(): Promise<void>;
}
