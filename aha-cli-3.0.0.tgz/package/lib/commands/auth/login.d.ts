import BaseCommand from '../../base';
declare class Login extends BaseCommand {
    static description: string;
    static flags: {
        authServer: import("../../lib/flags").StringFlagConfig;
        browser: import("../../lib/flags").StringFlagConfig;
    };
    run(): Promise<void>;
    private saveToken;
}
export default Login;
