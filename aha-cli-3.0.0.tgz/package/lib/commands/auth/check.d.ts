import BaseCommand from '../../base';
export default class Check extends BaseCommand {
    static needsAuth: boolean;
    static description: string;
    static flags: {
        [x: string]: import("../../lib/flags").FlagDefinition;
    };
    run(): Promise<void>;
}
